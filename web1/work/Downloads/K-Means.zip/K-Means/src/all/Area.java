package all;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.HashSet;

import javax.swing.JComponent;
import javax.swing.event.MouseInputListener;

public class Area extends JComponent implements MouseInputListener {

	Dimension initial_size = new Dimension(500, 500);
	HashSet<Point> pointset = new HashSet<>();
	DrawPoints dp;

/*this constructor is used to add the mouse functionalities to the current label and set background color
	*/
	public Area(DrawPoints dp) {
		this.dp = dp;
		addMouseListener(this);
		addMouseMotionListener(this);
		setBackground(Color.pink);
		setOpaque(true);
	}

	public Dimension getPreferredSize() {
		return initial_size;
	} 
//paint graphics
	protected void paintComponent(Graphics g) {
		if (isOpaque()) {
			g.setColor(getBackground());
			g.fillRect(0, 0, getWidth(), getHeight());
		}
//this tells the dimensions and color of the ploted point that we click
		for (Point point : pointset) {
			if (point != null) {
				g.setColor(getForeground());
				g.fillRect(point.x - 1, point.y - 1, 3, 3);
			}
		}

	}

/*
 *  this method is used to read the current X & Y positions of mouse point when clicked 
 *	and it will redirect to "updateclickpoint(current)" method which is used for updating the cursor point
 *	each time the mouse clicked.
 */
	
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		Point current = new Point(x, y);
	
		pointset.add(current);
		this.dp.updateClickPoint(current);
		repaint();
	}

/*
 * this method is used to capture the x & y  position whenever the mouse point is moving 
 *  
 * 
 */
	
	public void mouseMoved(MouseEvent e) {
		dp.redrawCursor(e.getX(), e.getY());
	}

	public void mouseExited(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
	}
}