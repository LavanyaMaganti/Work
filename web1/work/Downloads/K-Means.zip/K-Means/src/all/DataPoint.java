package all;


public class DataPoint {
private int cluster_id;
private double [] facets;
private int nod;
private double dist;
public DataPoint(int nod)
{
	this.dist=Double.MAX_VALUE;
	this.nod=nod;
	this.facets= new double[nod];
}
public DataPoint(double facets[])
{
	this.facets= new double[facets.length];
	for(int i=0;i<facets.length;i++)
	{
		this.facets[i]=facets[i];
	}
	this.dist=Double.MAX_VALUE;
	this.nod=facets.length;
}
public void setFacet(int pos,double value)
{
	this.facets[pos]=value;
}
public double getDist()
{
	return this.dist;
}
public double getFacet(int pos)
{
	return this.facets[pos];
}
public void setCLuster(int cluster_id)
{
	this.cluster_id=cluster_id;
}
public int getCluster()
{
	return this.cluster_id;
}
public double[] getFacets()
{
	return this.facets;
}
public double getEcludianDistance(DataPoint other)
{
	//this method is used to find the ecludian distance between current point and the point passed as augment 
	double sum_squares =0;
	for(int i=0;i<nod;i++)
	{
		double diff=this.getFacet(i)-other.getFacet(i);
		sum_squares+=(diff*diff);
	}
	return Math.sqrt(sum_squares);
}
public void setDistance(double dist)
{
	this.dist=dist;
}
@Override
public String toString()
{
	StringBuffer sb= new StringBuffer();
	for(double s:this.facets)sb.append(s+"\t");
	return sb.substring(0, sb.length()-1).toString();
}
}
