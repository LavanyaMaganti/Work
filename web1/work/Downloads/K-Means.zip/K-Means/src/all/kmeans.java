package all;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class kmeans {
	private double updateCentroids() {
		
		////find the mean of the points for each cluster and assign that as new centroid for that cluster
		double error = 0;
		double[][] sums = new double[centroids.length][this.nod];
		int [] clu_num= new int[this.noc];
		for (DataPoint dp : this.dataPoints) {
			clu_num[dp.getCluster()]++;
			for (int i = 0; i < this.nod; i++)
				sums[dp.getCluster()][i] += dp.getFacet(i);
		}

		for (int k = 0; k < centroids.length; k++) {
			DataPoint old = new DataPoint(centroids[k].getFacets());
			for (int l = 0; l < this.nod; l++)
				centroids[k].setFacet(l, sums[k][l] / clu_num[k]);
			error += old.getEcludianDistance(centroids[k]);

		}
		return error;
	}

	private void assignCentroids() {
		// for all datapoints the distance to all centroids is evaluated and the
		// point is assigned to cluster which has the lowest ecludian distance
	
		for (DataPoint dp : this.dataPoints) {
			for (int i = 0; i < centroids.length; i++) {
				double di = dp.getEcludianDistance(centroids[i]);
				if (di < dp.getDist()) {
					dp.setCLuster(i);
					dp.setDistance(di);
				}
			}
		}
	}

	private ArrayList<DataPoint> dataPoints = new ArrayList<>();
	DataPoint[] centroids;
	private int noc, nod;

	public static void main(String[] args) throws IOException {
		// creating scanner object to read data from system input
		Scanner sc = new Scanner(System.in);
		
		 String file_name= "outfilename.CSV";
		// initilizing buffered reader to read the file
		//C:\Users\vasanthi\workspace\K-Means\outfilename.txt
		BufferedReader br = new BufferedReader(new FileReader(file_name));

		System.out.println("Enter the number of dimensions for the data");
		kmeans k = new kmeans();
		// takng no of dimensions
		k.nod = sc.nextInt();
		System.out.println("Enter the number of clusters you want");
		// taking no of clusters for kmeans
		k.noc = sc.nextInt();
		// initilizing centroids array
		k.centroids = new DataPoint[k.noc];
		String data;
		int read = 0;
		// reading each line and making data point for each record
		while ((data = br.readLine()) != null) {
			String sp[] = data.split(",");
			DataPoint dp = new DataPoint(k.nod);
			for (int i = 0; i < k.nod; i++)
				dp.setFacet(i, Double.parseDouble(sp[i]));
			k.dataPoints.add(dp);
			if (read < k.noc) {
				// making 1st k points as initial seed points for centroid
				k.centroids[read] = new DataPoint(dp.getFacets());
			}

			read++;
		}
		int cycles = 0;

		System.out.println("compleated reading");
		//printing initial seed
		for(DataPoint ce:k.centroids)
			System.out.println(ce);
		
		
		// updating centroids until the till the error is less than negligible
		// value
		while (true) {
			cycles++;
			// this method is used to assign centroids for all the points
			k.assignCentroids();
			// this method is used to update centroid points by calculating mean
			// of all the data points in the cluster
			double error = k.updateCentroids();
			System.out.println("The error is " + error + " continuing in cycle " + cycles);
			// if the error is less than the preset value then breaking the loop
			if (error < 0.001) {
				break;
			}
		}

		System.out.println("The number of cycles is " + cycles);

		
		
		for(DataPoint ce:k.centroids)
			System.out.println(ce);
			
		int i = 0;
		System.out.println("Compleated clustering");
		// printing the cluster informatin for all points
		for (DataPoint d : k.dataPoints) {

			System.out.println("Point " + i++ + "\t belongs to " + d.getCluster() + " cluster");
		}

	}

}