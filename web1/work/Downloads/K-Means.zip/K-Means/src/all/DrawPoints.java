package all;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class DrawPoints {

	JTextArea ta = new JTextArea();
	JLabel label = new JLabel();
	Point cursorPos;
	int cnt=0;
//create a jframe called plotpoints
	public static void main(String args[]) {
		
		
		JFrame f = new JFrame("Plot Points");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		DrawPoints draw = new DrawPoints();

		draw.buildDynamicPointAddition(f.getContentPane());

		f.pack();
		f.setVisible(true);
	}
/*used to print the output screen into 3 diff segements when their dimensions are given:
 * 1. plotting area
 * 2.text area
 * 3.label
 */
	
	private void buildDynamicPointAddition(Container cp) {

		cp.setLayout(new BoxLayout(cp, BoxLayout.PAGE_AXIS));
		
		Area box = new Area(this);
		//plotting area
		cp.add(box);

		JScrollPane s = new JScrollPane(ta);
		//text area content
		ta.setEditable(false);
      
	    s.setPreferredSize(new Dimension(500, 200));
		cp.add(s);
       //points out the cursor position
		cp.add(label);

		// TODO Auto-generated method stub

	}

	protected void redrawLabel() {
//prints the cursor position in the lable when cuesor is moved
		if (cursorPos != null) {
			this.label.setText("The cursor is at (" + cursorPos.x + ", " + cursorPos.y + "). ");
		}

	}
//reads the cursor coodinates when the curser is moved
	public void redrawCursor(int x, int y) {

		if (!(x > 0 && y > 0)) {
			redrawLabel();
			cursorPos = null;
			return;
		}

		if (cursorPos == null) {
			cursorPos = new Point();
		}

		cursorPos.x = x;
		cursorPos.y = y;
		redrawLabel();
	}
// updates the newly added x & y values to the text area 
	public void updateClickPoint(Point p) {
		String file = "src/all/outfilename.CSV";
	
		  if(cnt==0){
			  try(
					    PrintWriter out = new PrintWriter(file))
					{
				      out.println( p.getX() + "," + p.getY() );
					} catch (IOException e) {
					    //exception handling left as an exercise for the reader
					}
					
		  }
		  else{
			  try(FileWriter fw = new FileWriter(file, true);
					    BufferedWriter bw = new BufferedWriter(fw);
					    PrintWriter out = new PrintWriter(bw))
					{
				      out.println( p.getX() + "," + p.getY() );
					
		  
		    
		} catch (IOException e) {
		    //exception handling left as an exercise for the reader
		}
		}
		cnt++;
		ta.append("new point at " + p.getX() + "," + p.getY() + " is added.\n");
	   ta.setCaretPosition(ta.getDocument().getLength());
	}	

}
